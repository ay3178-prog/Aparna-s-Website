let video;
let faceMesh;
let faces = [];

let box1Dots = [];
let box2Dots = [];
let box3Dots = [];
let box4Dots = [];

let box1Trails = [];
let box2Trails = [];
let box3Trails = [];
let box4Trails = [];

let box1Name = "";
let box2Name = "";
let box3Name = "";
let box4Name = "";

let nextBox = 1;
let drawingTrail = null;

const NAMES = ["fragmented", "isolated", "together", "community", "alone", "stranded", "chaos"];

function preload() {
  faceMesh = ml5.faceMesh({ maxFaces: 1, flipped: true });
}

function setup() {
  createCanvas(640, 540);
  video = createCapture(VIDEO, { flipped: true });
  video.size(640, 480);
  video.hide();
  faceMesh.detectStart(video, gotFaces);

  let freezeBtn = createButton('Freeze next');
  freezeBtn.position(20, 580);
  freezeBtn.mousePressed(freezeNext);

  let clearBtn = createButton('Clear');
  clearBtn.position(120, 580);
  clearBtn.mousePressed(clearAll);

  let printBtn = createButton('Print');
  printBtn.position(180, 580);
  printBtn.mousePressed(savePrint);
}

function gotFaces(results) {
  faces = results;
}

function draw() {
  background(255);

  stroke(0);
  noFill();
  
  line(10, 10, 320, 10);
  line(320, 10, 320, 250);
  line(320, 250, 10, 250);
  line(10, 250, 10, 10);
  
  line(330, 10, 630, 10);
  line(630, 10, 630, 250);
  line(630, 250, 330, 250);
  line(330, 250, 330, 10);
  
  line(10, 260, 320, 260);
  line(320, 260, 320, 500);
  line(320, 500, 10, 500);
  line(10, 500, 10, 260);
  
  line(330, 260, 630, 260);
  line(630, 260, 630, 500);
  line(630, 500, 330, 500);
  line(330, 500, 330, 260);

  drawBox(box1Dots, box1Trails, box1Name, 1);
  drawBox(box2Dots, box2Trails, box2Name, 2);
  drawBox(box3Dots, box3Trails, box3Name, 3);
  drawBox(box4Dots, box4Trails, box4Name, 4);

  if (nextBox <= 4 && faces.length > 0) {
    let pts = faces[0].keypoints;
    let bx = 0;
    let by = 0;
    if (nextBox === 1) { bx = 10; by = 10; }
    if (nextBox === 2) { bx = 330; by = 10; }
    if (nextBox === 3) { bx = 10; by = 260; }
    if (nextBox === 4) { bx = 330; by = 260; }
    
    noStroke();
    fill(0);
    for (let i = 0; i < pts.length; i++) {
      circle(bx + pts[i].x * 0.45, by + pts[i].y * 0.45, 2);
    }
  }
}

function drawBox(dots, trails, name, num) {
  if (dots.length === 0) {
    return;
  }
  
  noFill();
  strokeWeight(2);
  for (let i = 0; i < trails.length; i++) {
    let t = trails[i];
    stroke(t.color[0], t.color[1], t.color[2]);
    beginShape();
    for (let j = 0; j < t.points.length; j++) {
      vertex(t.points[j].x, t.points[j].y);
    }
    endShape();
  }
  
  noStroke();
  fill(0);
  for (let i = 0; i < dots.length; i++) {
    circle(dots[i].x, dots[i].y, 3);
  }
  
  fill(0);
  textSize(11);
  textAlign(CENTER);
  let labelX = 0;
  let labelY = 0;
  if (num === 1) { labelX = 165; labelY = 240; }
  if (num === 2) { labelX = 480; labelY = 240; }
  if (num === 3) { labelX = 165; labelY = 490; }
  if (num === 4) { labelX = 480; labelY = 490; }
  text(name, labelX, labelY);
}

function freezeNext() {
  if (faces.length === 0) return;
  if (nextBox > 4) return;
  
  let pts = faces[0].keypoints;
  let bx = 0;
  let by = 0;
  if (nextBox === 1) { bx = 10; by = 10; }
  if (nextBox === 2) { bx = 330; by = 10; }
  if (nextBox === 3) { bx = 10; by = 260; }
  if (nextBox === 4) { bx = 330; by = 260; }
  
  let saved = [];
  for (let i = 0; i < pts.length; i++) {
    saved.push({
      x: bx + pts[i].x * 0.45,
      y: by + pts[i].y * 0.45
    });
  }
  
  let randomName = NAMES[floor(random(NAMES.length))];
  
  if (nextBox === 1) { box1Dots = saved; box1Name = randomName; }
  if (nextBox === 2) { box2Dots = saved; box2Name = randomName; }
  if (nextBox === 3) { box3Dots = saved; box3Name = randomName; }
  if (nextBox === 4) { box4Dots = saved; box4Name = randomName; }
  
  nextBox = nextBox + 1;
}

function clearAll() {
  box1Dots = [];
  box2Dots = [];
  box3Dots = [];
  box4Dots = [];
  box1Trails = [];
  box2Trails = [];
  box3Trails = [];
  box4Trails = [];
  box1Name = "";
  box2Name = "";
  box3Name = "";
  box4Name = "";
  nextBox = 1;
  drawingTrail = null;
}

function mousePressed() {
  let boxNum = whichBox(mouseX, mouseY);
  if (boxNum === 0) return;
  
  let newTrail = {
    color: [floor(random(256)), floor(random(256)), floor(random(256))],
    points: [{ x: mouseX, y: mouseY }],
    box: boxNum
  };
  
  if (boxNum === 1) box1Trails.push(newTrail);
  if (boxNum === 2) box2Trails.push(newTrail);
  if (boxNum === 3) box3Trails.push(newTrail);
  if (boxNum === 4) box4Trails.push(newTrail);
  
  drawingTrail = newTrail;
}

function mouseDragged() {
  if (drawingTrail === null) return;
  drawingTrail.points.push({ x: mouseX, y: mouseY });
}

function mouseReleased() {
  drawingTrail = null;
}

function whichBox(x, y) {
  if (x >= 10 && x <= 320 && y >= 10 && y <= 250) {
    if (box1Dots.length > 0) return 1;
  }
  if (x >= 330 && x <= 630 && y >= 10 && y <= 250) {
    if (box2Dots.length > 0) return 2;
  }
  if (x >= 10 && x <= 320 && y >= 260 && y <= 500) {
    if (box3Dots.length > 0) return 3;
  }
  if (x >= 330 && x <= 630 && y >= 260 && y <= 500) {
    if (box4Dots.length > 0) return 4;
  }
  return 0;
}

function savePrint() {
  saveCanvas('faces', 'png');
}